import { createStore } from "vuex";
import axios from "axios";
export default createStore({
  state: {
    member: null,
    token: "",
    authError: null,
  },
  getters: {},
  mutations: {
    SET_TOKEN: (state, token) => {
      state.token = token;
    },
    SET_MEMBER_INFO: (state, memberInfo) => {
      console.log(memberInfo);
      state.member = memberInfo;
    },
  },
  actions: {
    checkCode({ state }, { code }) {
      console.log("state", state);
      // console.log("axios", code);
      //const url = "api/login";
      return axios.get(`http://localhost:8080/api/login?code=${code}`);
    },
  },
});
