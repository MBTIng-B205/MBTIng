// import $axios from "axios";

export const meetings = {
  namespaced: true,
  state: () => ({}),
  mutations: {},
  getters: {},
  actions: {},
};
