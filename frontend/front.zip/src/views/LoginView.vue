<template>
  <MBTISetting :member="member" />
</template>

<script>
import { useStore } from "vuex";
import { onMounted } from "vue";
import { useRouter } from "vue-router";
export default {
  setup() {
    const store = useStore();
    const router = useRouter();
    onMounted(() => {
      const code = router.currentRoute._value.query.code;
      // console.log(useStore());
      // console.log(store);
      // console.log(code);

      store
        .dispatch("accounts/checkCode", { code })
        .then(function (result) {
          //store.commit("SET_MEMBER_INFO", result.data.member);
          console.log("member data check", result.data.member);
          sessionStorage.setItem("access-token", result.data.jwt);
          console.log(result.data.member);
          store.commit("accounts/SET_MEMBER_INFO", result.data.member);
          if (result.data.visited === true) {
            store.dispatch("accounts/getMemberinfo").then(function (res) {
              store.commit("accounts/SET_MEMBER_INFO", res.data);
              console.log(res.data);
            });
            router.push({ path: "/" });
          } else {
            router.push({ path: "/MBTISetting" });
          }
        })
        .catch(function (err) {
          alert(err);
        });
    });
    return {};
  },
};
</script>

<style></style>
